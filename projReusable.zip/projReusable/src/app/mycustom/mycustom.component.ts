import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-mycustom',
  templateUrl: './mycustom.component.html',
  styleUrls: ['./mycustom.component.css']
})
export class MycustomComponent implements OnInit {

  constructor(private service:MyserviceService) { }

  dataColl: any = [];
  count = 0;
  headFlag = false;

  downloadContent() { debugger;
let flag = true;
    this.dataColl.forEach( (item,idx) => {


      if(item.status == 'available') {
flag = false;
       

          let a = document.createElement("a");
          document.body.appendChild(a);
          var url = item.path;
          a.href = url;
          let n = item.path.lastIndexOf("\\");
          var s = item.path.substring(n+1, item.path.length);
          a.download = s;
          a.click();
      }

    });

    if (flag) {
      alert('No Files selected to download');
    }

  }

  changeHeaderSeletion(checked) {
    this.count = 0;
    this.dataColl.forEach( (item,idx) => {
       
        if(!checked) {
          item.status = 'scheduled';
        
        }
        else {
          item.status = 'available';
          this.count++;
        }
  })
}

  changeContentSeletion(index,chked) {debugger;
    let totalct = 0;
    this.count = 0;
    this.dataColl.forEach( (item,idx) => {
      if(index == idx) {
        if(!chked) 
        item.status = 'scheduled';
        else 
          item.status = 'available';
          this.count++;
      }
       
    });
     
    this.dataColl.forEach( (item,idx) => {
      if (item.status == 'available') {  
        totalct++;
      }
    });
    if(totalct === this.dataColl.length) {
      this.headFlag = true;

    }
    else {
      this.headFlag = false;
    }
  }

  ngOnInit(): void {
 
    this.dataColl = this.service.data;
    this.count = 0;
    for(let data of this.dataColl) {
      if (data.status == 'available') {
        this.count++;
      }
    }

    if( this.count === this.dataColl.length) {
      this.headFlag = true;

    }
    else {
      this.headFlag = false;
    }
  }

}
